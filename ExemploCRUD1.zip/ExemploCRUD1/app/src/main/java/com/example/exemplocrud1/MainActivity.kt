package com.example.exemplocrud1

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.exemplocrud1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializando o View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configurando o botão de salvar
        binding.btnSalvar.setOnClickListener {
            val nome = binding.inputNome.text.toString()
            val cpf = binding.inputCpf.text.toString()
            val telefone = binding.inputTelefone.text.toString()

            if (nome.isNotEmpty() && cpf.isNotEmpty() && telefone.isNotEmpty()) {
                // Mostra uma mensagem que o aluno foi salvo
                Toast.makeText(this, "Aluno inserido: $nome, CPF: $cpf, Tel: $telefone", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
