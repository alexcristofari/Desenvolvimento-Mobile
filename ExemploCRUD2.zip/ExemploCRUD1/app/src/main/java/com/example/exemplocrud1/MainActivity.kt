package com.example.exemplocrud1

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.exemplocrud1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val alunos = arrayListOf("João", "Maria", "Pedro", "Ana", "Lucas")
    private lateinit var adaptador: ArrayAdapter<String>
    private var alunoSelecionado: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializando o View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializando o adaptador e conectando a lista de alunos ao ListView
        adaptador = ArrayAdapter(this, android.R.layout.simple_list_item_1, alunos)
        binding.listaDeAlunos.adapter = adaptador

        // Desabilitar o botão de atualizar inicialmente
        binding.btnAtualizar.isEnabled = false

        // Configurando o clique em itens do ListView para selecionar o aluno
        binding.listaDeAlunos.setOnItemClickListener { _, _, position, _ ->
            alunoSelecionado = position
            binding.inputNome.setText(alunos[position])
            binding.btnAtualizar.isEnabled = true // Habilitar o botão de atualizar após selecionar o aluno
        }

        // Salvando um novo aluno
        binding.btnSalvar.setOnClickListener {
            val nome = binding.inputNome.text.toString()
            if (nome.isNotEmpty()) {
                alunos.add(nome)
                adaptador.notifyDataSetChanged()
                limparCampos()
                Toast.makeText(this, "Aluno inserido: $nome", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Por favor, insira o nome do aluno.", Toast.LENGTH_SHORT).show()
            }
        }

        // Atualizando um aluno selecionado
        binding.btnAtualizar.setOnClickListener {
            if (alunoSelecionado != -1) {
                val nomeAtualizado = binding.inputNome.text.toString()
                if (nomeAtualizado.isNotEmpty()) {
                    alunos[alunoSelecionado] = nomeAtualizado
                    adaptador.notifyDataSetChanged()
                    limparCampos()
                    Toast.makeText(this, "Aluno atualizado: $nomeAtualizado", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Por favor, insira o nome atualizado.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Selecione um aluno para atualizar.", Toast.LENGTH_SHORT).show()
            }
        }

        // Excluindo um aluno selecionado
        binding.btnExcluir.setOnClickListener {
            if (alunoSelecionado != -1) {
                val nomeExcluido = alunos[alunoSelecionado]
                alunos.removeAt(alunoSelecionado)
                adaptador.notifyDataSetChanged()
                limparCampos()
                Toast.makeText(this, "Aluno excluído: $nomeExcluido", Toast.LENGTH_LONG).show()
                binding.btnAtualizar.isEnabled = false // Desabilitar o botão de atualizar após a exclusão
            } else {
                Toast.makeText(this, "Selecione um aluno para excluir.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Função para limpar os campos de entrada e resetar a seleção
    private fun limparCampos() {
        binding.inputNome.setText("")
        alunoSelecionado = -1
        binding.btnAtualizar.isEnabled = false // Desabilitar o botão de atualizar ao limpar
    }
}
